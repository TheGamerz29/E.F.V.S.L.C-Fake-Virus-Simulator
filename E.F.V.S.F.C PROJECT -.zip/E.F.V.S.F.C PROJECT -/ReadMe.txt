This project is about Fake virus launcher that simulates hyper realistic fake virus.
mostly,the code got written by myself but there is a few of them i copied from the internet
you can find the credits in the code yourself.

Made by Wan Adli a.k.a TheGamerz,Mr.Gamerz.

@2020

copyrights TheGamerz Or Adli
copying is allowed but please credit.