 -=Batch Snake v2.2=-
By Kolto101 and Kolt Koding
Project began Jan 18, 2011
Last updated: December 5, 2011

Thank you for playing Batch Snake! I hope you enjoy it. If you do not know how to play, then view
the "How To Play" section within the game.

If you do not understand something, or wish to talk, then email me at: kolto101@gmail.com
A "How To Play section is included in the game.

 -=Updates from 2.0 to 2.2=-

  <2.2> -Added 'colous.exe' to [optionally] remove flicker.
         This may slow downt the game, but it looks much smoother. 

 �<2.1.1> - Fixed Highscore logging AND rock generation

  <2.0>

 -Added automatic updating option [experimental]. Requires "wget.exe", which
  comes with the Batch Snake package. Wget is also provided at koltkoding.tk.
  NOTE: Batch Snake will automatically update ONLY when opened, and only when
  the option is turned on.

 -Added theme/skin option to the editor. The option to not allow the force in
  scheme change was also added. 

 -Added small changes in the code for efficiency. Hopefully more is to come.

 The next update should include the option to download maps from Kolt Koding,
 and internal code changes.


 -=OS Requirements=-

Tested and works on:

�Windows XP (Will most likely require a choice command download. Read below.)
�Windows Vista
�Windows 7

Windows Command Prompt is required to play.
The choice command is also required. If you recieve an error regarding the choice command, or the input box
closes when you try to play, you can download the choice command via koltkoding.tk. 

There are 2 versions:
choice.com - 16 bit - www.koltkoding.tk/batch_files/choice.com
choice.exe - 32 bit - www.koltkoding.tk/batch_files/choice.exe

If you do not know which one to download, try both versions.


 -=Speed and Buffer settings=-

� As of 2.2, Batch Snake will utilize 'colous.exe' to remove the flicker effect. This may slow the
  game a little. If it is too slow or unsatisfying, turn the "No Flicker" effect off.

Batch Snake works best on faster computers. Unfortunately, there isn't much that can be done if your
computer is slow. Closing uneccessary process will greatly increase the effeciency of the game.

If your computer is too fast, changing the speed and buffer settings within the game will help slow it
down. Both can be used in combinations, or only one if preferred. The buffer setting is more precise,
and can use larger numbers. Try experimenting with both to get the best results.


 -=KNOWN BUGS=-

-Food may occasionally not appear when spawned. When this happens,
 retrace the snake's path and search until it's found.

-Taskkill does not seem to close input.bat.

-Recent updates may still be buggy. Please report ANY bugs found.


 -=Reporting a bug=-

When reporting a bug, please try to answer these questions as best as you can:

-Did it only happen once, or multiple times?
-What section did the bug appear in?
-Did the bug last only for a second, or did it last for awhile?
-What were the EXACT settings? (This includes graphical settings, such as skins)
-What operating system are you using?
-Any other details you know will help!

Report to kolto101@gmail.com

Thank you for your support!
