lands_of_death_READ_ME_file

Thanks for downloading the LOD package! Greatly appreciated.
This game was created by Dr_Al_ and is not to be distributed without his permission.
For more information about older versions, go to the LOD versions document.

*WARNING* This game is a text-based adventure game only, so don't expect
there to be any first-person shooting or 2D platforming.

*REQUIREMENTS*
1. Windows. Yeah... it doesn't work too well on a Mac.
2. Wifi. Without internet connection, waits (pings) will jump between fast and slow. I'm pretty sure, that is. It's unpredictable.
3. Reliable computer. Gameplay can get reasonably laggy when there isn't enough disk space available.
If this happens, try quitting open programs to free up some memory. I'm joking of course. It's a BATCH file.

*ALERTS*
* Before playing the game, you MUST ensure that you have ALL the LoD componenets (vitalsaves.data, winpoints.data, etc.)
in the SAME FOLDER as the actual Lands of Death .cmd file.
* To start the game, simply double-click the cmd file. Duh.

*RULES*
1. DO NOT CHANGE/EDIT THE SCRIPT.
2. This game took a very long time to make. Give it some credit.
3. No in-game cheating unless absolutley necessary.

You can contact me at ThisIsDoctorAl@gmail.com
If your lucky, I'll be bothered to check my gmail account!
Don't forget to check out my YouTube channel! @Dr_Al_ @ThisIsDoctorAl
And follow me on Instagram! @Dr_Al_
Actually, don't follow me on Instagram. I don't use it anymore.

P.S. I was only a young teenager when I started to code this game, and it will always be a part of my life.
This game means a lot to me, and the fact that you're reading this means even more to me.

Dr_Al_ Coding� 2013-2016 LTD. PTY.