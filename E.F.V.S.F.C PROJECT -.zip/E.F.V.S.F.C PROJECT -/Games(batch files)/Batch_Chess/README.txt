 -=Batch Ches v0.8=-
By Kolto101 and Kolt Koding
Project began Dec, 2011
Last updated: Sept 16, 2012

!!!NOTE!!! Kolt Koding is currently down. Contact me at kolto101@gmail.com

Thank you for playing Batch Chess! I've put a lot of effort into it, so I hope you enjoy it.
While Batch Chess is packed with features, it does not have a checkmate/stalemate checking
system. IT CAN, however, check to see if either king is in check.
Feel free to email me [below] if you have coding ideas.

If you do not know how to play, then visit http://en.wikipedia.org/wiki/Rules_of_chess

If you do not understand something, or wish to talk, then email me at: kolto101@gmail.com


 -=Updates=-

 None yet; first release


 -=OS Requirements=-

Tested and works on:

�Windows XP (Will most likely require a choice command download. Read below.)
�Windows Vista
�Windows 7

Windows Command Prompt is required to play.
The choice command is also required. If you recieve an error regarding the choice command, or the input box
closes when you try to play, you can download the choice command via koltkoding.tk. 

There are 2 versions:
choice.com - 16 bit - http://www.mediafire.com/?4jwxa6hwvize6c4
choice.exe - 32 bit - http://www.mediafire.com/?867kqk4zax70net

If you do not know which one to download, try both versions.


 -=KNOWN BUGS=-

-While the game has been tested quite a bit, their may still be bugs. PLEASE report
 ANY bugs found to: kolto101@gmail.com
-The lack of color IS NOT a bug. Different colors may be implemented in the future.


 -=Reporting a bug=-

When reporting a bug, please try to answer these questions as best as you can:

-Did it only happen once, or multiple times?
-What section did the bug appear in?
-Did the bug last only for a second, or did it last for awhile?
-What were the EXACT settings? (This includes graphical settings)
-What operating system are you using?
-Any other details you know will help!

Report to kolto101@gmail.com

Thank you for your support!